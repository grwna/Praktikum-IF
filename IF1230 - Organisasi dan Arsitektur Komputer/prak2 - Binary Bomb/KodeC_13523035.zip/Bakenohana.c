#include <stdint.h>

void check(int param1, int param2){
    uint64_t edx = param1;   
    uint64_t eax = param2;

    uint8_t ox1c = edx;
    uint8_t ox20 = eax;
    uint64_t ecx;
    int oxc = 0;
    while(oxc <= 5){
        eax = 3*oxc;
        eax = (uint32_t)((0x4ec4ec4f * (eax + ox1c)) >> 32);
        eax = eax >> 3;
        eax -= (ox1c >> 31);
        eax = (ox1c - (eax * 26)) + 97;
        ox1c = (uint8_t)eax;

        if (ox1c > 'z'){
            edx = (uint8_t) (79 * ox1c);
            eax = (uint16_t) eax >> 8;
            eax = (uint8_t) eax >> 3 - (uint8_t) edx >> 7;
            eax = edx - (26 * eax) + 97;
            ox1c = (uint8_t) eax;
        }
        if(ox20 == ox1c){   // Win condition
            return;
        }
        oxc += 1;
    } 
    trap();
}

void Bakenohana(char* input_strings){
    int eax, par2;
    int params2[6] = {105,102,115,116,105}; // ifsti
    for (int i = 0; i < 6; i++){
        eax = input_strings[i];
        par2 = params2[i];
        check(eax, par2);
    }   
/* iterasi sampai selesai, kalo ada input salah, kena trap di dalam check*/ 
stage_complete();
}