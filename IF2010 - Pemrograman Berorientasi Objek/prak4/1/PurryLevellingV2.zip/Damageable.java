interface Damageable {
    void takeDamage(int damage);
}