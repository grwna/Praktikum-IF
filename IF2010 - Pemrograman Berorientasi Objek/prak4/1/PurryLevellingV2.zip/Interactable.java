interface Interactable {
    void interact();
}