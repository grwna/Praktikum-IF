class Robot implements CanWalk, CanTalk{
    public void walk(){
        System.out.println("Robot is walking");
    }

    public void talk(){
        System.out.println("Robot is talking");
    }
}