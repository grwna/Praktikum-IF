# include "hapus-duplikat.h"
# include <stdio.h>

int main(){
    List l1,l2,l3;
    ElType val;
    CreateList(&l1);
    CreateList(&l2);
    // for(int i; i < 10; i++) {
    //     insertLast(&l1,i+1);
    //     // insertLast(&l2,i+6);
    // }
    
    insertLast(&l1, 2);
    l3 = hapusDuplikat(l1);
    printf("\n");
    displayList(l3);
    printf("\n");

    return 0;
}